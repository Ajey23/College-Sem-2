#include<iostream>
using namespace std;
class DEMO
{
	public:
		int n1,n2;
		void inline get1()
	{
		cout<<"enter 2 numbers ";
		cin>>n1>>n2;
	}
	void inline get2()
	{ 
		cout<<"square  of number is="<<endl;
		int sq=n1*n1;
		cout <<sq<<endl;
		int sq1=n2*n2;
		cout<<sq1<<endl;
	}
	void inline get3()
	{    cout<<"cube of number is="<<endl;
		int cu= n1*n1*n1;
		cout <<cu<<endl;
		int cu1=n2*n2*n2;
		cout<<cu1<<endl;
	}
	void inline get4()
	{  cout<<"Find small number"<<endl;
	         (n1<n2)?cout<<"a is smaller":cout<<" b is smaller";
		
		
	}
	
};
int main()
{
	DEMO d1;
	d1.get1();
	d1.get2();
	d1.get3();
	d1.get4();
}
		