//Pointer variable
using namespace std;
#include<iostream>
int main()
{
	int* p;
	int a=15;
	p=&a;//assigning address of a to pointer variable
	//p=a;
	cout<<p<<endl;
	cout<<a<<endl;
	cout<<&a<<endl;
}