using namespace std;
#include<iostream>
int main()
{
	int a=10;
	int* p;
	p=&a;
	cout<<p<<endl; //display address of a
	cout<<a<<endl; //display value of a 10
	cout<<&p<<endl;//display address of pointer var p
	cout<<*p<<endl;//diplay value of pointing variable -> a
	cout<<&a<<endl;//display address of a
}