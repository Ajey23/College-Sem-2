using namespace std;
#include<iostream>
int main()
{
	int a[10]={1,2,3,4,5,6,7,8,9,10};
	int* p;
	int i;
	p=a;//p=a[0];
	cout<<"Size of a:"<<sizeof(a)<<endl;
	cout<<"Size of p:"<<sizeof(p)<<endl;
	for(i=1;i<=10;i++)
	{
		cout<<p<<"    ";
		p++;
	}
	
	/*int a=10;
	float f=20.256;
	char c='H';
	double d=52.123458;
	int* i=&a;
	float* fp =&f;
	char* cp=&c;
	double* dp=&d;
	cout<<"sizeof a:"<<sizeof(a)<<endl;
	cout<<"sizeof i:"<<sizeof(i)<<endl;
	cout<<"sizeof f:"<<sizeof(f)<<endl;
	cout<<"sizeof fp:"<<sizeof(fp)<<endl;
	cout<<"sizeof c:"<<sizeof(c)<<endl;
	cout<<"sizeof cp:"<<sizeof(cp)<<	endl;
	cout<<"sizeof d:"<<sizeof(d)<<endl;
	cout<<"sizeof dp:"<<sizeof(dp)<<endl;
	*/
}
	