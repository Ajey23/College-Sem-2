//Pointer
using namespace std;
#include<iostream>
int main()
{
	int a=10,b=20;
	cout<<"Address of variable a"<<&a<<endl;
	cout<<"Address of variable b"<<&b<<endl;
}