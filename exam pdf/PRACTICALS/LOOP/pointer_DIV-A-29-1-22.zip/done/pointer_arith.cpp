//Pointer Arithmetic
using namespace std;
#include<iostream>
int main()
{
	int a=1,b=2;
	int *pa,*pb;
	pa=&a;//pa is storing address of a
	pb=&b;//pb is storing address of b
	cout<<"Address of a"<<&a<<endl;
	cout<<"Address of b"<<&b<<endl;
	cout<<"Value of a"<<a<<endl;
	cout<<"value of b"<<b<<endl;
	cout<<"Value of pa"<<pa<<endl;
	cout<<"Value of pb"<<pb<<endl;
	
	cout<<"Increment"<<endl;
	(*pa)++;
	cout<<*pa<<endl;//a++ - pa++
	cout<<a<<endl;
	(*pb)++;
	cout<<*pb<<endl;
	cout<<b;
}
