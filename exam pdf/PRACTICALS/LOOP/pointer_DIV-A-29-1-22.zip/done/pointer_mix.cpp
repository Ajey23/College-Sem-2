using namespace std;
#include<iostream>
int main()
{
	int a;
	char b[10];
	cout<<"Address of a"<<&a<<endl;
	cout<<"Address of b"<<&b<<endl;
	cout<<"Size of a:"<<sizeof(a)<<endl;
	cout<<"Size of b:char array"<<sizeof(b)<<endl;
}