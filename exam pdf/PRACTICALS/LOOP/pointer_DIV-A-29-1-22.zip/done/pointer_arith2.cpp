//Pointer Arithmetic
using namespace std;
#include<iostream>
int main()
{
	int a=1,b=2,c;
	int *pa,*pb;
	pa=&a;
	pb=&b;
	c=*pa+*pb;//c=a+b ->statement are same
	cout<<"Addition :"<<c<<endl;
}