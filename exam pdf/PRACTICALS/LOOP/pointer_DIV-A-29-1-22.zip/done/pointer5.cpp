//Swap
using namespace std;
#include<iostream>
void swap(int* a, int* b);
int main()
{
	int a,b;
	cout<<"Enter value of a & b";
	cin>>a>>b;//a=10,b=20
	cout<<"Value of a"<<a<<endl;//10
	cout<<"Value of b"<<b<<endl;//20
	swap(&a,&b);
	cout<<"Value after swapping"<<endl;
	cout<<"Value of a"<<a<<endl;//20
	cout<<"Value of b"<<b<<endl;//10
}
void swap(int* a, int* b)
{
	int c;
	c=*a;//c=10
	*a=*b;//a=20
	*b=c;//b=10
}