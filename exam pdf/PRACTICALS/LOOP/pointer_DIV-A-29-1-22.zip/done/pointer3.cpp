using namespace std;
#include<iostream>
int main()
{
	int a=26;
	int* p;
	p=&a;//pointer variable - storing address of a
	cout<<"Value of a"<<a<<endl;
	cout<<"Value of a via pointer"<<*p<<endl;
	//a=36;
	*p=36;//print value of address pointer var pointing to
	cout<<"Updated Value of a"<<a<<endl;
	cout<<"Updated Value of a via pointer"<<*p<<endl;
	cout<<p<<endl;
}