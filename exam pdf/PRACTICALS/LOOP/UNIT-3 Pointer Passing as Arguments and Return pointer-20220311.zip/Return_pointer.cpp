#include<iostream>
#include<string.h>
//Pointers and Functions
//returning pointer from function
using namespace std;
int* add(int px,int py);
int main()
{
	int x=10,y=20;
	//int *p=&x;
	int *s=add(x,y);
	cout<<"\n sum is:"<<*s;
	*s=40;
	cout<<"\n sum is:"<<*s;
	return 0;
}
int* add(int px,int py)
{
	int *sum=px+py;
	return sum;
}